# Cover Letter Drafting Prompt (Agent 5)

Used by `agents/cover_letter_agent.py::draft_cover_letter_text()`.

Write a ~300-350 word cover letter for the role below. Ground every claim
in the candidate's actual resume data provided — never invent skills or
experience. Reference 1-2 specific matched skills/projects. Keep tone
confident, specific, and non-generic.

Candidate resume data:
{resume_json}

Job description:
{job_description}

Matched skills: {matched_skills}
