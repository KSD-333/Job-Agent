"""
FastAPI entrypoint exposing the Career Agent pipeline.

Run:
    uvicorn app:app --reload

Endpoints:
    POST /run-pipeline        -> runs the full main graph once
    POST /interview-prep      -> runs the interview-prep graph for one company
    POST /tracker/status      -> manually update a company's tracker status
    GET  /analytics           -> returns the latest analytics snapshot
"""

from fastapi import FastAPI
from pydantic import BaseModel

from graph_flow.graph import build_graph, build_interview_graph
from agents.tracker_agent import update_status

app = FastAPI(title="AI Career Agent")

main_graph = build_graph()
interview_graph = build_interview_graph()


class PipelineRequest(BaseModel):
    resume_path: str = "resumes/master_resume.pdf"
    match_threshold: float = 70.0


class InterviewRequest(BaseModel):
    company: str


class StatusUpdateRequest(BaseModel):
    company: str
    status: str  # Applied | Interview | Rejected | Offer


@app.post("/run-pipeline")
def run_pipeline(req: PipelineRequest):
    initial_state = {
        "resume_path": req.resume_path,
        "match_threshold": req.match_threshold,
        "errors": [],
    }
    final_state = main_graph.invoke(initial_state)
    return {
        "qualified_matches": final_state.get("qualified_matches", []),
        "analytics": final_state.get("analytics", {}),
        "missing_skill_report": final_state.get("missing_skill_report", {}),
        "errors": final_state.get("errors", []),
    }


@app.post("/interview-prep")
def run_interview_prep(req: InterviewRequest):
    final_state = interview_graph.invoke({
        "interview_company": req.company,
        "errors": [],
    })
    return {
        "interview_questions": final_state.get("interview_questions", {}),
        "errors": final_state.get("errors", []),
    }


@app.post("/tracker/status")
def set_status(req: StatusUpdateRequest):
    update_status(req.company, req.status)
    return {"ok": True, "company": req.company, "status": req.status}


@app.get("/health")
def health():
    return {"status": "ok"}
