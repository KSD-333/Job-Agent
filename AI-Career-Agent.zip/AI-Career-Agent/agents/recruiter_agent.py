"""
Agent 6 — Recruiter Research Agent

Looks up a plausible hiring manager / recruiter contact for each company
you're applying to, using only public sources (company careers page, public
LinkedIn search results). Writes contact.json per company.

Ethics/legal note: this agent should NOT guess personal emails at scale or
scrape private LinkedIn data. Keep it to publicly listed contacts (careers
page "contact us", public recruiter posts) and let the user manually verify
before outreach.

TODO:
    - search_company_careers_page(): find a public contact/recruiter email
      listed on the company's own careers page
    - search_public_linkedin(): use LinkedIn's public search (or a
      compliant API) to find people with "recruiter"/"talent" in their
      title at the target company
    - write_contact_json(): persist findings to database/history or a
      per-company folder as contact.json
"""

import json
import os

from graph_flow.state import CareerAgentState, ContactInfo

CONTACTS_DIR = "database/history"


def search_company_careers_page(company: str) -> dict:
    """TODO: fetch the company's careers page and extract any listed
    recruiter/HR contact info."""
    raise NotImplementedError("Wire up careers-page contact lookup here.")


def search_public_linkedin(company: str) -> dict:
    """TODO: query public LinkedIn search results for recruiters/talent
    acquisition staff at this company. Respect ToS — public search only,
    no authenticated scraping of private profiles."""
    raise NotImplementedError("Wire up public LinkedIn recruiter search here.")


def write_contact_json(company: str, contact: ContactInfo) -> str:
    path = os.path.join(CONTACTS_DIR, company, "contact.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(contact, f, indent=2)
    return path


def run_recruiter_agent(state: CareerAgentState) -> dict:
    """LangGraph node. Looks up a contact for each qualified match's company."""
    matches = state.get("qualified_matches", [])
    contacts = {}
    errors = []

    for match in matches:
        company = match["company"]
        try:
            careers_info = search_company_careers_page(company)
            linkedin_info = search_public_linkedin(company)
            contact: ContactInfo = {
                "company": company,
                "hiring_manager": linkedin_info.get("hiring_manager"),
                "recruiter": linkedin_info.get("recruiter") or careers_info.get("recruiter"),
                "email": careers_info.get("email"),
                "linkedin_url": linkedin_info.get("linkedin_url"),
                "source": "careers_page+linkedin_public_search",
            }
            write_contact_json(company, contact)
            contacts[company] = contact
        except NotImplementedError as e:
            errors.append(f"recruiter_agent[{company}]: {e}")

    return {"contacts": contacts, "errors": errors}
