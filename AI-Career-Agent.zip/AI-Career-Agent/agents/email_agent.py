"""
Agent 9 — Notification Agent

Sends a daily digest (Gmail SMTP) and/or Telegram message summarizing
today's qualified matches. Runs as the final node in the main graph.

TODO:
    - format_digest(): turn qualified_matches into a readable summary
      ("Google 94%, Amazon 92%, Zoho 90%...")
    - send_email(): Gmail SMTP send using app-password auth (never hardcode
      credentials — read from environment variables via utils/config.py)
    - send_telegram(): POST to the Telegram Bot API sendMessage endpoint
"""

import os

from graph_flow.state import CareerAgentState


def format_digest(qualified_matches: list) -> str:
    if not qualified_matches:
        return "No new qualified matches today."
    lines = ["Today's Jobs:"]
    for m in sorted(qualified_matches, key=lambda m: m["score"], reverse=True):
        lines.append(f"  {m['company']} — {m['role']} — {m['score']}%")
    return "\n".join(lines)


def send_email(subject: str, body: str):
    """TODO: send via Gmail SMTP using credentials from environment
    variables (GMAIL_USER, GMAIL_APP_PASSWORD) — see utils/config.py."""
    raise NotImplementedError("Wire up Gmail SMTP send here.")


def send_telegram(message: str):
    """TODO: POST to https://api.telegram.org/bot{TOKEN}/sendMessage
    using TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID from environment."""
    raise NotImplementedError("Wire up Telegram bot send here.")


def run_notification_agent(state: CareerAgentState) -> dict:
    """LangGraph node. Sends the daily digest; failures here shouldn't
    fail the whole pipeline run, just get logged as errors."""
    matches = state.get("qualified_matches", [])
    digest = format_digest(matches)
    errors = []

    try:
        send_email(subject=f"{len(matches)} new job matches today", body=digest)
    except NotImplementedError as e:
        errors.append(f"email_agent[email]: {e}")

    try:
        send_telegram(digest)
    except NotImplementedError as e:
        errors.append(f"email_agent[telegram]: {e}")

    return {"notifications_sent": len(errors) == 0, "errors": errors}
