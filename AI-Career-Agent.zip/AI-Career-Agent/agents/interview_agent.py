"""
Agent 7 — Interview Prep Agent

Triggered separately from the main pipeline (see build_interview_graph in
graph_flow/graph.py), when a company's tracker status flips to
"Interview". Generates a question set tailored to that specific role/JD
across DSA, system design, language-specific, and behavioral categories.

TODO:
    - load_job_context(): pull the stored jd.txt + resume_json for the
      company from database/history/{company}/
    - generate_question_set(): LLM call producing categorized questions
      (role-specific language e.g. Java/Android, DSA, System Design,
      Behavioral, Coding Problems) grounded in the actual JD + resume gaps
    - write_report(): save to reports/{company}_interview_prep.json (and
      optionally render a Markdown/PDF study guide)
"""

import json
import os

from graph_flow.state import CareerAgentState

REPORTS_DIR = "reports"


def load_job_context(company: str) -> dict:
    """TODO: read database/history/{company}/jd.txt and resumes/resume.json."""
    raise NotImplementedError("Wire up job context loading here.")


def generate_question_set(job_context: dict) -> dict:
    """TODO: LLM call producing a dict like:
    {
      "language_specific": [...],
      "dsa": [...],
      "system_design": [...],
      "behavioral": [...],
      "coding_problems": [...]
    }
    """
    raise NotImplementedError("Wire up interview question generation here.")


def write_report(company: str, questions: dict) -> str:
    os.makedirs(REPORTS_DIR, exist_ok=True)
    path = os.path.join(REPORTS_DIR, f"{company}_interview_prep.json")
    with open(path, "w") as f:
        json.dump(questions, f, indent=2)
    return path


def run_interview_agent(state: CareerAgentState) -> dict:
    """LangGraph node for the standalone interview-prep graph.
    Expects state['interview_company'] to be set by the caller."""
    company = state.get("interview_company")
    if not company:
        return {"errors": ["interview_agent: no interview_company set in state"]}

    try:
        context = load_job_context(company)
        questions = generate_question_set(context)
        write_report(company, questions)
        return {"interview_questions": questions}
    except NotImplementedError as e:
        return {"errors": [f"interview_agent[{company}]: {e}"]}
