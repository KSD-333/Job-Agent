"""
Agent 5 — Cover Letter Agent

Generates a distinct .docx cover letter per company, grounded in
resume_json + the specific job description so each letter references real
projects/skills rather than generic filler.

TODO:
    - draft_cover_letter_text(): LLM call using resume_json + job
      description + matched_skills, kept to ~300-350 words
    - render_cover_letter_docx(): use python-docx to apply a clean letter
      template (date, greeting, 3 paragraphs, sign-off)
"""

import os

from graph_flow.state import CareerAgentState, MatchResult

OUTPUT_DIR = "cover_letters"


def draft_cover_letter_text(resume_json: dict, match: MatchResult, job_description: str) -> str:
    """TODO: LLM call to draft the letter body grounded in real resume content."""
    raise NotImplementedError("Wire up LLM cover letter drafting here.")


def render_cover_letter_docx(company: str, letter_text: str) -> str:
    """TODO: use python-docx to render letter_text into a formatted .docx.
    Returns the output filepath."""
    raise NotImplementedError("Wire up python-docx rendering here.")


def run_cover_letter_agent(state: CareerAgentState) -> dict:
    """LangGraph node. Generates one cover letter per qualified match."""
    resume_json = state.get("resume_json", {})
    matches = state.get("qualified_matches", [])
    jobs_by_id = {j.get("job_id"): j for j in state.get("normalized_jobs", [])}

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    cover_letters = {}
    errors = []

    for match in matches:
        company = match["company"]
        job = jobs_by_id.get(match.get("job_id"), {})
        try:
            text = draft_cover_letter_text(resume_json, match, job.get("description", ""))
            path = render_cover_letter_docx(company, text)
            cover_letters[company] = path
        except NotImplementedError as e:
            errors.append(f"cover_letter_agent[{company}]: {e}")

    return {"cover_letters": cover_letters, "errors": errors}
