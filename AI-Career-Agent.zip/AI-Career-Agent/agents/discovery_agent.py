"""
Agent 2 — Job Discovery Agent

Scrapes/queries job sources and returns a flat list of Job dicts.
Each source gets its own fetch_* function so sources can be added,
disabled, or rate-limited independently.

Start with Greenhouse / Lever / YC Jobs — they have stable, scrape-friendly
public endpoints. Treat LinkedIn / Naukri / Wellfound as higher-risk
(ToS + anti-bot); gate them behind a config flag and prefer official APIs
where available.

TODO:
    - fetch_greenhouse_jobs(): use the public Greenhouse Job Board API
      (https://boards-api.greenhouse.io/v1/boards/{company}/jobs)
    - fetch_lever_jobs(): use the public Lever API
      (https://api.lever.co/v0/postings/{company})
    - fetch_yc_jobs(): scrape/query workatastartup.com listings
    - fetch_linkedin_jobs() / fetch_naukri_jobs() / fetch_wellfound_jobs():
      implement carefully with Playwright, respect rate limits and ToS,
      keep behind an explicit opt-in flag
"""

from typing import List
import hashlib

from graph_flow.state import CareerAgentState, Job

# Companies/boards to query. Move this to a config file once it grows.
TARGET_COMPANIES = {
    "greenhouse": [],   # e.g. ["stripe", "airbnb"]
    "lever": [],        # e.g. ["netflix"]
}


def _job_id(company: str, role: str) -> str:
    return hashlib.sha256(f"{company}:{role}".encode()).hexdigest()[:16]


def fetch_greenhouse_jobs(board_tokens: List[str]) -> List[Job]:
    """TODO: GET https://boards-api.greenhouse.io/v1/boards/{token}/jobs
    for each token and map into Job dicts."""
    raise NotImplementedError("Wire up Greenhouse API calls here.")


def fetch_lever_jobs(company_slugs: List[str]) -> List[Job]:
    """TODO: GET https://api.lever.co/v0/postings/{slug} for each slug
    and map into Job dicts."""
    raise NotImplementedError("Wire up Lever API calls here.")


def fetch_yc_jobs() -> List[Job]:
    """TODO: query Work at a Startup / YC Jobs listings."""
    raise NotImplementedError("Wire up YC Jobs source here.")


def run_discovery_agent(state: CareerAgentState) -> dict:
    """LangGraph node. Aggregates all enabled sources into raw_jobs.
    Any source that isn't implemented yet is skipped with an error note
    instead of crashing the whole pipeline."""
    jobs: List[Job] = []
    errors: List[str] = []

    sources = [
        ("greenhouse", fetch_greenhouse_jobs, TARGET_COMPANIES["greenhouse"]),
        ("lever", fetch_lever_jobs, TARGET_COMPANIES["lever"]),
    ]

    for name, fetch_fn, arg in sources:
        try:
            fetched = fetch_fn(arg)
            jobs.extend(fetched)
        except NotImplementedError as e:
            errors.append(f"discovery_agent[{name}]: {e}")

    for job in jobs:
        job["job_id"] = _job_id(job.get("company", ""), job.get("role", ""))

    return {"raw_jobs": jobs, "errors": errors}
